# -*- coding: utf-8 -*-
from aqt.utils import tr


# Form implementation generated from reading ui file 'qt/aqt/forms/reposition.ui'
#
# Created by: PyQt5 UI code generator 5.14.1
#
# WARNING! All changes made in this file will be lost!


from PyQt5 import QtCore, QtGui, QtWidgets


class Ui_Dialog(object):
    def setupUi(self, Dialog):
        Dialog.setObjectName("Dialog")
        Dialog.resize(299, 229)
        self.verticalLayout = QtWidgets.QVBoxLayout(Dialog)
        self.verticalLayout.setObjectName("verticalLayout")
        self.label = QtWidgets.QLabel(Dialog)
        self.label.setText("")
        self.label.setObjectName("label")
        self.verticalLayout.addWidget(self.label)
        self.gridLayout = QtWidgets.QGridLayout()
        self.gridLayout.setObjectName("gridLayout")
        self.label_2 = QtWidgets.QLabel(Dialog)
        self.label_2.setObjectName("label_2")
        self.gridLayout.addWidget(self.label_2, 0, 0, 1, 1)
        self.start = QtWidgets.QSpinBox(Dialog)
        self.start.setMinimum(0)
        self.start.setMaximum(1000000)
        self.start.setProperty("value", 0)
        self.start.setObjectName("start")
        self.gridLayout.addWidget(self.start, 0, 1, 1, 1)
        self.label_3 = QtWidgets.QLabel(Dialog)
        self.label_3.setObjectName("label_3")
        self.gridLayout.addWidget(self.label_3, 1, 0, 1, 1)
        self.step = QtWidgets.QSpinBox(Dialog)
        self.step.setMinimum(1)
        self.step.setMaximum(10000)
        self.step.setObjectName("step")
        self.gridLayout.addWidget(self.step, 1, 1, 1, 1)
        self.verticalLayout.addLayout(self.gridLayout)
        self.randomize = QtWidgets.QCheckBox(Dialog)
        self.randomize.setObjectName("randomize")
        self.verticalLayout.addWidget(self.randomize)
        self.shift = QtWidgets.QCheckBox(Dialog)
        self.shift.setChecked(False)
        self.shift.setObjectName("shift")
        self.verticalLayout.addWidget(self.shift)
        spacerItem = QtWidgets.QSpacerItem(20, 40, QtWidgets.QSizePolicy.Minimum, QtWidgets.QSizePolicy.Expanding)
        self.verticalLayout.addItem(spacerItem)
        self.buttonBox = QtWidgets.QDialogButtonBox(Dialog)
        self.buttonBox.setOrientation(QtCore.Qt.Horizontal)
        self.buttonBox.setStandardButtons(QtWidgets.QDialogButtonBox.Cancel|QtWidgets.QDialogButtonBox.Ok)  # type: ignore
        self.buttonBox.setObjectName("buttonBox")
        self.verticalLayout.addWidget(self.buttonBox)

        self.retranslateUi(Dialog)
        self.buttonBox.accepted.connect(Dialog.accept)  # type: ignore
        self.buttonBox.rejected.connect(Dialog.reject)  # type: ignore
        QtCore.QMetaObject.connectSlotsByName(Dialog)
        Dialog.setTabOrder(self.start, self.step)
        Dialog.setTabOrder(self.step, self.randomize)
        Dialog.setTabOrder(self.randomize, self.shift)
        Dialog.setTabOrder(self.shift, self.buttonBox)

    def retranslateUi(self, Dialog):
        _translate = QtCore.QCoreApplication.translate
        Dialog.setWindowTitle(tr.browsing_reposition_new_cards())
        self.label_2.setText(tr.browsing_start_position())
        self.label_3.setText(tr.browsing_step())
        self.randomize.setText(tr.browsing_randomize_order())
        self.shift.setText(tr.browsing_shift_position_of_existing_cards())